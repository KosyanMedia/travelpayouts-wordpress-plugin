<?php
/**
 * Created by PhpStorm.
 * User: freeman
 * Date: 07.08.15
 * Time: 0:41
 */

interface KPDDefault {
    public static function defaultOptions();
}