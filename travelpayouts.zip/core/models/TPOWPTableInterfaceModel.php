<?php
/**
 * Created by PhpStorm.
 * User: freeman
 * Date: 11.08.15
 * Time: 8:40
 */
namespace core\models;
interface TPOWPTableInterfaceModel {
    public static function createTable();
    public static function deleteTable();
}